/* Encrypt test version 1.2 - MAX CHAR = 32767*/

/* Use Notepad++ for correctly wiev this source */

/* Developer: Jacopo "Zenek" Mengarelli (@Hastro)*/

/* Include Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Definition of function*/

/* Global Var*/


/* Main Function*/
void main()
{
	
	/* Local Declaration */
	
	char 	chose,					/* switch variable */
			fname[20],	 			/* file_name.extension */
			video_char[32767];		/* print at video the file */
	FILE 	*txt = NULL;			/* buffer for file */
	int 	flag,		 			/* flag for Crypt/decrypt*/
			esito_lettura;			/* input validation */
			
	/* This do is used for the input validation (University of Urbino - Italia) */
	do 
	{
		printf("\nMain menu(v1.2)\n\n\tInput the txt file name (Example: file.txt)>");
		
		esito_lettura=scanf("%s",fname);
		
		if (esito_lettura != 1)
			printf("Input non accettabile!\n");
			while (getchar() != '\n');
	}
	while (esito_lettura != 1);
	
	
	/* Main Menu */
	printf("\n\n\tA) Read the file\n\tB) Crypt file\n\tC) Decrypt file\n\n>");
	chose = getchar();

	/* Clean the console  */
	printf("\e[1;1H\e[2J"); 
	

	
	/* Start Switch */
	switch (chose)
	{
     case 'A': // Read the file
	 case 'a': // Read the file
     printf("Your choice: A\n");
	 
		/* Check if the file is available*/
		if ((txt = fopen(fname,"r")) == NULL) // file not available 
		{
			 printf("Error detected during the opening file process...\n\n");
			 exit(1);
		}
		else // file available 
		{
			 printf("\n--Tentativo di lettura file--\n\n"); 
			 while(!feof(txt)) // print at video the file 
			 {
				 fscanf(txt,"%s", video_char);
				 printf("%s",video_char);
			 }
		}
		printf("\n\n--Chiusura del file...--\n\n");
		fclose(txt);
     break;
/* ============================================================================================================================ */
     case 'B':
	 case 'b':
     printf("Your choice: B\n\nLoading resources...\n");
	 
		char  ch;
		FILE *fptt; /* tmp pointer */	
		
		
		
		sleep(3);
		txt=fopen(fname, "r"); 			// try to open your file (custom)
		if(txt==NULL) 					// if not possible 
		{
			printf("\n\tFile does not exists or error in opening..!!");
			exit(1);
		}
		fptt=fopen("temp.txt", "w"); 	// try to open the tmp file 
		if(fptt==NULL) 					// if the creation of tmp file gone wrong 
		{
			printf("\n\tError in creation of file temp.txt ..!!");
			fclose(txt);
			exit(2);
		}
		while(1) 				// probably one of the most dangerous validation ... i will update it in future!
		{
			ch=fgetc(txt); 		// link the txt file to pointer
			if(ch==EOF) 		// if ch == End Of File ... this is a classic validation 
			{
				break; 			// if ch == EOF --> you reach the end of the file. You can now exit! 
			}
			else 				// if the file have not reach the end, continue to read and encrypt it
			{
				ch=ch+200; 		// ENCRYPTION SYSTEM HERE
				fputc(ch, fptt);
			}
		}
		fclose(txt); 	// exit from our file once the encryption is end 
		fclose(fptt); 	// exit from tmp file once the encryption is end 
		txt=fopen(fname, "w"); 			// opening our file (custom)
		if(txt==NULL)					// if the opening fail
		{
			printf("\n\tFile does not exists or error in opening..!!");
			exit(3); // <-- check the different exit error !
		}
		fptt=fopen("temp.txt", "r");	// opening the tmp file 
		if(fptt==NULL)					// if the opening fail
		{
			printf("\n\tFile does not exists or error in opening..!!");
			fclose(txt);
			exit(4); // <-- check the different exit error !
		}
		while(1) // another bad validation ... i will update it soon ! 
		{
			ch=fgetc(fptt);
			if(ch==EOF)
			{
				break;
			}
			else
			{
				fputc(ch, txt);
			}
		}
		printf("\n\n\t--File %s successfully encrypted--\n\n", fname);
		fclose(txt);
		fclose(fptt);
	 
     break;
/* ============================================================================================================================ */	 
	 case 'C':
	 case 'c':
     printf("Your choice: C\n\nLoading resources...\n");
	 
	
	sleep(3);	
	txt=fopen(fname, "r");
	if(txt==NULL)
	{
		printf(" File does not exists or error in opening..!!");
		exit(1);
	}
	fptt=fopen("temp.txt", "w");
	if(fptt==NULL)
	{
		printf(" Error in creation of file temp.txt ..!!");
		fclose(txt);
		exit(2);
	}
	while(1)
	{
		ch=fgetc(txt);
		if(ch==EOF)
		{
			break;
		}
		else
		{
			ch=ch-200; // DECRYPTION SYSTEM HERE
			fputc(ch, fptt);
		}
	}
	fclose(txt);
	fclose(fptt);
	txt=fopen(fname, "w");
	if(txt==NULL)
	{
		printf(" File does not exists or error in opening..!!");
		exit(3);
	}
	fptt=fopen("temp.txt", "r");
	if(fptt==NULL)
	{
		printf(" File does not exists or error in opening..!!");
		fclose(txt);
		exit(4);
	}
	while(1)
	{
		ch=fgetc(fptt);
		if(ch==EOF)
		{
			break;
		}
		else
		{
			fputc(ch, txt);
		}
	}
	printf("\n\n\tFile %s successfully decrypted ..!!\n\n", fname);
	fclose(txt);
	fclose(fptt);
	 
     break;
	 
     default:
     printf("Incorrect chose. Please retry!\n");
     break;
	}
	
	
}
